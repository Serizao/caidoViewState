import { defineComponent as h, ref as g, onMounted as x, createElementBlock as i, openBlock as l, createElementVNode as e, toDisplayString as u, createTextVNode as b, Fragment as w, renderList as v, createCommentVNode as y, normalizeClass as m, h as S } from "vue";
class _ {
  /**
   * Analyze a ViewState string
   */
  static analyze(a) {
    const t = {
      isValid: !1,
      isEncrypted: !1,
      isSigned: !1,
      raw: a,
      details: {}
    };
    if (!a || a.trim().length === 0)
      return t.error = "Empty ViewState", t;
    try {
      const r = atob(a.replace(/-/g, "+").replace(/_/g, "/"));
      t.decoded = r, t.isValid = !0;
      const o = r.charCodeAt(0);
      return t.details.version = `0x${o.toString(16).padStart(2, "0")}`, t.isSigned = this.checkForHMAC(r), t.details.hasHMAC = t.isSigned, t.isEncrypted = this.checkForEncryption(r), t.details.encryptionDetected = t.isEncrypted, t;
    } catch (r) {
      return t.error = r instanceof Error ? r.message : "Invalid base64", t;
    }
  }
  /**
   * Check if ViewState contains HMAC signature
   */
  static checkForHMAC(a) {
    if (a.length < 20)
      return !1;
    const r = a.slice(-32);
    return this.calculateEntropy(r) > 7.5;
  }
  /**
   * Check if ViewState is encrypted
   */
  static checkForEncryption(a) {
    const t = this.calculateEntropy(a);
    if (t > 7.5)
      return !0;
    const r = /[\x0f\x1e\x1f]/.test(a), o = /[a-zA-Z]{4,}/.test(a);
    return r && o ? !1 : t > 6.5;
  }
  /**
   * Calculate Shannon entropy of a string
   */
  static calculateEntropy(a) {
    const t = a.length, r = {};
    for (let d = 0; d < t; d++) {
      const s = a.charCodeAt(d);
      r[s] = (r[s] || 0) + 1;
    }
    let o = 0;
    for (const d in r) {
      const s = r[d] / t;
      o -= s * Math.log2(s);
    }
    return o;
  }
  /**
   * Extract ViewState from request body or query parameters
   */
  static extractViewState(a) {
    const t = [], r = /__VIEWSTATE=([^&\s]+)/gi;
    let o;
    for (; (o = r.exec(a)) !== null; )
      t.push(decodeURIComponent(o[1]));
    return t;
  }
}
const k = { class: "viewstate-analyzer p-4" }, V = {
  key: 0,
  class: "loading"
}, E = {
  key: 1,
  class: "error p-4 bg-red-900/20 border border-red-500 rounded"
}, A = { class: "text-red-400" }, q = {
  key: 2,
  class: "no-viewstate p-4 bg-yellow-900/20 border border-yellow-500 rounded"
}, C = {
  key: 3,
  class: "viewstate-results space-y-4"
}, M = { class: "text-lg font-semibold mb-3" }, I = { class: "status-grid grid grid-cols-3 gap-4 mb-4" }, z = { class: "flex items-center gap-2" }, N = {
  key: 0,
  class: "text-green-400"
}, R = {
  key: 1,
  class: "text-red-400"
}, T = { class: "flex items-center gap-2" }, H = {
  key: 0,
  class: "text-blue-400"
}, D = {
  key: 1,
  class: "text-gray-400"
}, F = { class: "flex items-center gap-2" }, B = {
  key: 0,
  class: "text-purple-400"
}, L = {
  key: 1,
  class: "text-gray-400"
}, P = { class: "details bg-gray-800/50 rounded p-3 mb-3" }, U = { class: "space-y-1 text-sm" }, W = {
  key: 0,
  class: "flex gap-2"
}, Y = { class: "font-mono" }, O = { class: "flex gap-2" }, Z = { class: "flex gap-2" }, $ = { class: "flex gap-2" }, j = {
  key: 0,
  class: "error-message bg-red-900/20 border border-red-500 rounded p-3 mb-3"
}, G = { class: "text-sm text-red-400" }, J = { class: "raw-viewstate" }, K = { class: "mt-2 p-3 bg-gray-900 rounded font-mono text-xs break-all" }, Q = /* @__PURE__ */ h({
  __name: "ViewStateAnalyzer",
  props: {
    sdk: {},
    requestId: {}
  },
  setup(c) {
    const a = c, t = g(!0), r = g(null), o = g([]);
    return x(async () => {
      try {
        const d = await a.sdk.requests.get(a.requestId);
        if (!d) {
          r.value = "Request not found", t.value = !1;
          return;
        }
        const s = d.raw || "", n = _.extractViewState(s);
        if (n.length === 0) {
          t.value = !1;
          return;
        }
        o.value = n.map((p) => ({
          raw: p,
          analysis: _.analyze(p)
        })), t.value = !1;
      } catch (d) {
        r.value = d instanceof Error ? d.message : "Unknown error", t.value = !1;
      }
    }), (d, s) => (l(), i("div", k, [
      t.value ? (l(), i("div", V, [...s[0] || (s[0] = [
        e(
          "p",
          null,
          "Loading request data...",
          -1
          /* CACHED */
        )
      ])])) : r.value ? (l(), i("div", E, [
        e(
          "p",
          A,
          u(r.value),
          1
          /* TEXT */
        )
      ])) : o.value.length === 0 ? (l(), i("div", q, [...s[1] || (s[1] = [
        e(
          "p",
          { class: "text-yellow-400" },
          "No ViewState found in this request.",
          -1
          /* CACHED */
        ),
        e(
          "p",
          { class: "text-sm text-gray-400 mt-2" },
          [
            b(" ViewState is typically found in ASP.NET applications with the parameter name "),
            e("code", null, "__VIEWSTATE"),
            b(". ")
          ],
          -1
          /* CACHED */
        )
      ])])) : (l(), i("div", C, [
        (l(!0), i(
          w,
          null,
          v(o.value, (n, p) => {
            var f;
            return l(), i("div", {
              key: p,
              class: "viewstate-item border rounded p-4"
            }, [
              e(
                "h3",
                M,
                "ViewState #" + u(p + 1),
                1
                /* TEXT */
              ),
              y(" Status indicators "),
              e("div", I, [
                e(
                  "div",
                  {
                    class: m(["status-card p-3 rounded", n.analysis.isValid ? "bg-green-900/20 border border-green-500" : "bg-red-900/20 border border-red-500"])
                  },
                  [
                    e("div", z, [
                      n.analysis.isValid ? (l(), i("span", N, "✓")) : (l(), i("span", R, "✗")),
                      s[2] || (s[2] = e(
                        "span",
                        { class: "font-medium" },
                        "Valid",
                        -1
                        /* CACHED */
                      ))
                    ])
                  ],
                  2
                  /* CLASS */
                ),
                e(
                  "div",
                  {
                    class: m(["status-card p-3 rounded", n.analysis.isSigned ? "bg-blue-900/20 border border-blue-500" : "bg-gray-700/20 border border-gray-600"])
                  },
                  [
                    e("div", T, [
                      n.analysis.isSigned ? (l(), i("span", H, "🔏")) : (l(), i("span", D, "○")),
                      s[3] || (s[3] = e(
                        "span",
                        { class: "font-medium" },
                        "Signed (MAC)",
                        -1
                        /* CACHED */
                      ))
                    ])
                  ],
                  2
                  /* CLASS */
                ),
                e(
                  "div",
                  {
                    class: m(["status-card p-3 rounded", n.analysis.isEncrypted ? "bg-purple-900/20 border border-purple-500" : "bg-gray-700/20 border border-gray-600"])
                  },
                  [
                    e("div", F, [
                      n.analysis.isEncrypted ? (l(), i("span", B, "🔒")) : (l(), i("span", L, "○")),
                      s[4] || (s[4] = e(
                        "span",
                        { class: "font-medium" },
                        "Encrypted",
                        -1
                        /* CACHED */
                      ))
                    ])
                  ],
                  2
                  /* CLASS */
                )
              ]),
              y(" Details "),
              e("div", P, [
                s[9] || (s[9] = e(
                  "h4",
                  { class: "text-sm font-semibold mb-2 text-gray-300" },
                  "Details",
                  -1
                  /* CACHED */
                )),
                e("dl", U, [
                  n.analysis.details.version ? (l(), i("div", W, [
                    s[5] || (s[5] = e(
                      "dt",
                      { class: "text-gray-400 min-w-32" },
                      "Version byte:",
                      -1
                      /* CACHED */
                    )),
                    e(
                      "dd",
                      Y,
                      u(n.analysis.details.version),
                      1
                      /* TEXT */
                    )
                  ])) : y("v-if", !0),
                  e("div", O, [
                    s[6] || (s[6] = e(
                      "dt",
                      { class: "text-gray-400 min-w-32" },
                      "Has HMAC:",
                      -1
                      /* CACHED */
                    )),
                    e(
                      "dd",
                      null,
                      u(n.analysis.details.hasHMAC ? "Yes" : "No"),
                      1
                      /* TEXT */
                    )
                  ]),
                  e("div", Z, [
                    s[7] || (s[7] = e(
                      "dt",
                      { class: "text-gray-400 min-w-32" },
                      "Encryption detected:",
                      -1
                      /* CACHED */
                    )),
                    e(
                      "dd",
                      null,
                      u(n.analysis.details.encryptionDetected ? "Yes" : "No"),
                      1
                      /* TEXT */
                    )
                  ]),
                  e("div", $, [
                    s[8] || (s[8] = e(
                      "dt",
                      { class: "text-gray-400 min-w-32" },
                      "Length:",
                      -1
                      /* CACHED */
                    )),
                    e(
                      "dd",
                      null,
                      u(n.raw.length) + " chars (" + u(((f = n.analysis.decoded) == null ? void 0 : f.length) || 0) + " bytes decoded)",
                      1
                      /* TEXT */
                    )
                  ])
                ])
              ]),
              y(" Error message if any "),
              n.analysis.error ? (l(), i("div", j, [
                e(
                  "p",
                  G,
                  "Error: " + u(n.analysis.error),
                  1
                  /* TEXT */
                )
              ])) : y("v-if", !0),
              y(" Raw ViewState (collapsible) "),
              e("details", J, [
                s[10] || (s[10] = e(
                  "summary",
                  { class: "cursor-pointer text-sm text-gray-400 hover:text-gray-200" },
                  " Show raw ViewState ",
                  -1
                  /* CACHED */
                )),
                e(
                  "div",
                  K,
                  u(n.raw),
                  1
                  /* TEXT */
                )
              ])
            ]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))
      ]))
    ]));
  }
}), X = (c, a) => {
  const t = c.__vccOpts || c;
  for (const [r, o] of a)
    t[r] = o;
  return t;
}, ee = /* @__PURE__ */ X(Q, [["__scopeId", "data-v-babf3f07"]]);
function se(c) {
  c.requests.addRequestViewMode({
    name: "ViewState",
    icon: "fas fa-eye",
    render: (a) => h({
      setup() {
        return () => S(ee, {
          sdk: c,
          requestId: a.request.getId()
        });
      }
    })
  }), c.window.showToast("ViewState Analyzer plugin loaded", {
    variant: "success",
    duration: 3e3
  });
}
export {
  se as init
};
